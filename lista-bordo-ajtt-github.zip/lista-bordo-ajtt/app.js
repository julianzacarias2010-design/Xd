import { initializeApp, getApps } from "https://www.gstatic.com/firebasejs/12.19.0/firebase-app.js";
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signInWithRedirect,
  getRedirectResult,
  signOut,
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.19.0/firebase-auth.js";
import {
  getFirestore,
  collection,
  addDoc,
  getDocs,
  getDoc,
  doc,
  deleteDoc,
  query,
  orderBy,
  limit,
  serverTimestamp,
  getCountFromServer,
  setDoc
} from "https://www.gstatic.com/firebasejs/12.19.0/firebase-firestore.js";
import { firebaseConfig } from "./firebase-config.js";

const proposals = [
  { id:"estatuto", no:"01", category:"derechos", label:"Derechos", title:"Actualizar y mejorar el Estatuto del Centro", text:"Actualizar el Estatuto para que responda a las necesidades actuales, facilitar que todas y todos puedan acceder a él y fortalecer el conocimiento y cumplimiento de nuestros derechos." },
  { id:"eventos", no:"02", category:"participacion", label:"Participación", title:"Eventos de manera periódica", text:"Organizar actividades durante todo el año: torneos en entreturnos, propuestas deportivas, ferias y eventos, tanto dentro como fuera del colegio cuando sea posible." },
  { id:"acondicionamiento", no:"03", category:"escuela", label:"Escuela", title:"Reacondicionar y mejorar los espacios", text:"Destinar el dinero recaudado a pintar aulas y marcos de puertas y ventanas y realizar otros trabajos de reacondicionamiento que puedan llevarse a cabo." },
  { id:"educacion-fisica", no:"04", category:"participacion", label:"Participación", title:"Intervenir en la Fiesta de Educación Física", text:"Participar directamente en la organización para aportar ideas y hacer que la Fiesta de Educación Física sea más amena para los estudiantes." },
  { id:"puertas", no:"05", category:"escuela", label:"Escuela", title:"Arreglar manijas y trabas de las aulas", text:"Comprar y reparar manijas, trabas y elementos necesarios para que las puertas de las aulas puedan utilizarse correctamente." },
  { id:"transparencia", no:"06", category:"transparencia", label:"Transparencia", title:"Comunicar todo lo que hacemos", text:"Mantener una comunicación clara y constante sobre actividades, proyectos, decisiones, ingresos, gastos y resultados, con un compromiso de transparencia total." },
  { id:"registro", no:"07", category:"transparencia", label:"Transparencia", title:"Organizar actas, notas, ingresos y gastos", text:"Llevar registros ordenados de la documentación y de los movimientos administrativos y económicos para facilitar su consulta y evitar problemas." },
  { id:"contacto", no:"08", category:"participacion", label:"Participación", title:"Hacer más fácil el contacto con el Centro", text:"Ampliar los canales de participación mediante la página web, un mail dedicado, Instagram, números de teléfono y presencia de integrantes del Centro cuando alguien necesite acercar algo." },
  { id:"cooperacion", no:"09", category:"cooperacion", label:"Cooperación", title:"Cooperar con otros Centros de Estudiantes", text:"Trabajar junto a otros Centros para compartir experiencias, encontrar soluciones con mayor rapidez y construir respuestas que puedan beneficiar a más estudiantes." },
  { id:"compromiso", no:"10", category:"escuela", label:"Compromiso", title:"Dejar la escuela mejor que como la encontramos", text:"Poner el esfuerzo y los recursos disponibles al servicio del cuidado, la mejora y el fortalecimiento de la institución, dando todo lo posible durante la gestión." }
];

const categoryNames = { all:"Todas", derechos:"Derechos", participacion:"Participación", escuela:"Escuela", transparencia:"Transparencia", cooperacion:"Cooperación" };
const state = { user:null, activeFilter:"all", sort:"order", search:"", stats:new Map(), comments:new Map(), expanded:new Set(), configured:false };

const $ = (selector, root=document) => root.querySelector(selector);
const $$ = (selector, root=document) => [...root.querySelectorAll(selector)];
const proposalById = id => proposals.find(p => p.id === id);

function isConfigured(cfg){ return cfg && cfg.apiKey && cfg.projectId && !String(cfg.apiKey).includes("REEMPLAZAR") && !String(cfg.projectId).includes("REEMPLAZAR"); }

let auth = null;
let db = null;
let googleProvider = new GoogleAuthProvider();

if (isConfigured(firebaseConfig)) {
  try {
    const app = getApps().length ? getApps()[0] : initializeApp(firebaseConfig);
    auth = getAuth(app);
    db = getFirestore(app);
    state.configured = true;
  } catch (err) {
    console.error(err);
  }
}

function escapeHtml(value=""){
  return String(value).replace(/[&<>'"]/g, char => ({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;","\"":"&quot;"}[char]));
}

function formatDate(value){
  if (!value) return "";
  const date = value?.toDate ? value.toDate() : new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  return new Intl.DateTimeFormat("es-AR", { day:"2-digit", month:"short", year:"numeric" }).format(date).replace(" de "," ");
}

function formatARS(value){
  if (typeof value !== "number") return "—";
  return new Intl.NumberFormat("es-AR", { style:"currency", currency:"ARS", maximumFractionDigits:0 }).format(value);
}

function toast(message, type="info"){
  const wrap = $("#toastStack");
  const el = document.createElement("div");
  el.className = `toast ${type}`;
  el.innerHTML = `<b>${type === "error" ? "Aviso" : type === "success" ? "Listo" : "Info"}</b><span>${escapeHtml(message)}</span>`;
  wrap.appendChild(el);
  setTimeout(() => el.remove(), 4300);
}

function showModal(id){
  const el = document.getElementById(id);
  if (!el) return;
  el.hidden = false;
  document.body.style.overflow = "hidden";
}
function closeModal(id){
  const el = document.getElementById(id);
  if (!el) return;
  el.hidden = true;
  if (!$$(".modal-backdrop:not([hidden])").length) document.body.style.overflow = "";
}
function closeAllModals(){ $$(".modal-backdrop").forEach(x => x.hidden = true); document.body.style.overflow = ""; }

function loginRequired(actionLabel="participar"){
  if (!state.configured){
    toast("Falta conectar este sitio con Firebase. Revisá el README y completá firebase-config.js.", "error");
    return;
  }
  if (state.user) return true;
  toast(`Necesitás iniciar sesión con Google para ${actionLabel}.`);
  showModal("authModal");
  return false;
}

async function login(){
  if (!state.configured){
    toast("Firebase todavía no está configurado en este proyecto.", "error");
    return;
  }
  try {
    if (window.matchMedia("(max-width: 800px)").matches) {
      await signInWithRedirect(auth, googleProvider);
    } else {
      await signInWithPopup(auth, googleProvider);
    }
  } catch (err) {
    console.error(err);
    toast(authErrorMessage(err), "error");
  }
}
function authErrorMessage(err){
  const code = err?.code || "";
  if (code.includes("popup-closed-by-user")) return "La ventana de inicio de sesión se cerró.";
  if (code.includes("unauthorized-domain")) return "Este dominio todavía no está autorizado en Firebase Authentication.";
  if (code.includes("popup-blocked")) return "El navegador bloqueó la ventana de Google. Probá nuevamente.";
  return "No se pudo iniciar sesión. Revisá la configuración de Firebase.";
}

function userInitial(user){ return (user?.displayName || user?.email || "E").trim().charAt(0).toUpperCase(); }
function avatarMarkup(user, cls=""){
  if (user?.photoURL) return `<img class="${cls}" src="${escapeHtml(user.photoURL)}" alt="" referrerpolicy="no-referrer">`;
  return `<span class="avatar-fallback ${cls}" aria-hidden="true">${escapeHtml(userInitial(user))}</span>`;
}

function updateAuthUI(){
  const signIn = $("#signInButton");
  const userChip = $("#userMenuButton");
  const footerIn = $("#footerAccountButton");
  const footerOut = $("#footerSignOutButton");
  if (state.user) {
    signIn.classList.add("hidden");
    userChip.classList.remove("hidden");
    userChip.innerHTML = `${avatarMarkup(state.user)}<span>${escapeHtml(state.user.displayName || "Mi cuenta")}</span>`;
    footerIn.classList.add("hidden"); footerOut.classList.remove("hidden");
  } else {
    signIn.classList.remove("hidden");
    userChip.classList.add("hidden");
    footerIn.classList.remove("hidden"); footerOut.classList.add("hidden");
  }
}

function proposalMatches(p){
  const filterOk = state.activeFilter === "all" || p.category === state.activeFilter;
  const q = state.search.trim().toLowerCase();
  const searchOk = !q || `${p.title} ${p.text} ${p.label}`.toLowerCase().includes(q);
  return filterOk && searchOk;
}

function renderProposals(){
  const grid = $("#proposalGrid");
  let list = proposals.filter(proposalMatches).slice();
  if (state.sort === "likes") list.sort((a,b) => (state.stats.get(b.id)?.likes || 0) - (state.stats.get(a.id)?.likes || 0));
  if (state.sort === "title") list.sort((a,b) => a.title.localeCompare(b.title, "es"));
  $("#proposalEmpty").classList.toggle("hidden", list.length > 0);
  grid.innerHTML = list.map(p => renderProposal(p)).join("");
  hydrateVisibleComments();
}

function renderProposal(p){
  const stats = state.stats.get(p.id) || { likes:0, liked:false, comments:0 };
  const expanded = state.expanded.has(p.id);
  const comments = state.comments.get(p.id) || null;
  return `<article class="proposal-card ${expanded ? "expanded" : ""}" data-proposal-id="${p.id}">
    <div class="proposal-head"><span class="proposal-no">${p.no}</span><span class="proposal-category">${escapeHtml(p.label)}</span></div>
    <h3>${escapeHtml(p.title)}</h3>
    <p>${escapeHtml(p.text)}</p>
    <div class="proposal-actions">
      <button class="like-button ${stats.liked ? "liked" : ""}" data-action="like" type="button" aria-label="${stats.liked ? "Quitar apoyo" : "Apoyar"} esta propuesta"><span>${stats.liked ? "♥" : "♡"}</span><span>${stats.likes}</span></button>
      <button class="comment-button" data-action="toggle-comments" type="button">💬 <span>${stats.comments}</span></button>
      <button class="apport-button" data-action="apport" type="button">Aportar</button>
      <span class="proposal-footer">${escapeHtml(p.label)}</span>
    </div>
    <div class="discussion-panel">
      <div class="discussion-head"><strong>Conversación</strong><small>Comentarios y aportes</small></div>
      <div class="comment-list">${comments === null ? '<div class="loading-row"><span class="spinner"></span> Cargando...</div>' : renderComments(comments, p.id)}</div>
    </div>
  </article>`;
}

function renderComments(comments, proposalId){
  if (!comments.length) return `<div class="empty-comments">Todavía no hay aportes públicos. Sé el primero en abrir la conversación.</div>`;
  return comments.map(c => {
    const mine = state.user?.uid && c.authorUid === state.user.uid;
    return `<div class="comment-item">
      ${c.photoURL ? `<img src="${escapeHtml(c.photoURL)}" alt="" referrerpolicy="no-referrer">` : `<span class="avatar-fallback">${escapeHtml((c.authorName||"E").charAt(0).toUpperCase())}</span>`}
      <div class="comment-body"><div class="comment-author"><span>${escapeHtml(c.authorName || "Estudiante")}</span><time>${escapeHtml(formatDate(c.createdAt))}</time></div><div class="comment-type">${escapeHtml(c.typeLabel || "Comentario")}</div><p>${escapeHtml(c.text)}</p>${mine ? `<div class="comment-actions"><button class="comment-delete" data-action="delete-comment" data-comment-id="${c.id}" data-proposal-id="${proposalId}" type="button">Eliminar</button></div>` : ""}</div>
    </div>`;
  }).join("");
}

async function fetchProposalStats(){
  if (!state.configured) {
    proposals.forEach(p => state.stats.set(p.id, { likes:0, liked:false, comments:0 }));
    renderProposals();
    return;
  }
  for (const p of proposals) {
    try {
      const likesRef = collection(db, "propuestas", p.id, "likes");
      const commentsRef = collection(db, "propuestas", p.id, "comentarios");
      const [likesCountSnap, commentsCountSnap, likedSnap] = await Promise.all([
        getCountFromServer(likesRef),
        getCountFromServer(commentsRef),
        state.user ? getDoc(doc(db, "propuestas", p.id, "likes", state.user.uid)) : Promise.resolve({ exists:()=>false })
      ]);
      state.stats.set(p.id, { likes: likesCountSnap.data().count, comments: commentsCountSnap.data().count, liked: likedSnap.exists() });
    } catch (err) {
      console.warn("No se pudieron cargar estadísticas de", p.id, err);
      state.stats.set(p.id, { likes:0, comments:0, liked:false });
    }
  }
  renderProposals();
}

async function hydrateVisibleComments(){
  if (!state.configured) return;
  for (const p of proposals.filter(p => state.expanded.has(p.id))) {
    if (state.comments.has(p.id)) continue;
    try {
      const q = query(collection(db, "propuestas", p.id, "comentarios"), orderBy("createdAt", "desc"), limit(60));
      const snap = await getDocs(q);
      const items = snap.docs.map(s => ({ id:s.id, ...s.data(), typeLabel: humanCommentType(s.data().type) }));
      state.comments.set(p.id, items);
      renderProposals();
    } catch (err) {
      console.warn(err);
      state.comments.set(p.id, []);
      renderProposals();
      toast("No se pudieron cargar los comentarios de esta propuesta.", "error");
    }
  }
}
function humanCommentType(type){ return ({comentario:"Comentario", sugerencia:"Sugerencia de mejora", solicitud:"Solicitud concreta", modificacion:"Modificación propuesta"})[type] || "Comentario"; }

async function createLike(proposalId){
  const likeRef = doc(db, "propuestas", proposalId, "likes", state.user.uid);
  try {
    await setDoc(likeRef, { uid: state.user.uid, createdAt: serverTimestamp() });
    const current = state.stats.get(proposalId) || { likes:0, comments:0, liked:false };
    state.stats.set(proposalId, {...current, likes:current.likes+1, liked:true});
    renderProposals();
    toast("Apoyo registrado.", "success");
  } catch (err) {
    console.error(err);
    toast("No se pudo registrar el apoyo.", "error");
  }
}

async function handleLike(proposalId){
  if (!loginRequired("dar apoyo")) return;
  const current = state.stats.get(proposalId) || {likes:0, comments:0, liked:false};
  if (current.liked) {
    try {
      await deleteDoc(doc(db, "propuestas", proposalId, "likes", state.user.uid));
      state.stats.set(proposalId,{...current, likes:Math.max(0,current.likes-1),liked:false});
      renderProposals();
      toast("Apoyo retirado.");
    } catch(err){ console.error(err); toast("No se pudo actualizar tu apoyo.","error"); }
  } else {
    await createLike(proposalId);
  }
}

async function openComments(proposalId){
  const card = document.querySelector(`.proposal-card[data-proposal-id="${CSS.escape(proposalId)}"]`);
  if (!card) return;
  if (state.expanded.has(proposalId)) state.expanded.delete(proposalId); else state.expanded.add(proposalId);
  renderProposals();
  if (state.expanded.has(proposalId) && !state.comments.has(proposalId)) await hydrateVisibleComments();
}

function openCommentModal(proposalId){
  if (!loginRequired("comentar o aportar")) return;
  const p = proposalById(proposalId);
  $("#commentProposalId").value = proposalId;
  $("#commentContext").textContent = p.title;
  $("#commentText").value = "";
  $("#commentCounter").textContent = "0 / 1000";
  showModal("commentModal");
  setTimeout(() => $("#commentText").focus(), 30);
}

async function submitComment(event){
  event.preventDefault();
  if (!loginRequired("comentar o aportar")) return;
  const proposalId = $("#commentProposalId").value;
  const type = $("#commentType").value;
  const textValue = $("#commentText").value.trim();
  if (textValue.length < 3) { toast("Escribí un aporte un poco más completo.", "error"); return; }
  if (textValue.length > 1000) { toast("El aporte excede los 1000 caracteres.", "error"); return; }
  try {
    await addDoc(collection(db, "propuestas", proposalId, "comentarios"), {
      authorUid: state.user.uid,
      authorName: state.user.displayName || "Estudiante",
      photoURL: state.user.photoURL || "",
      type,
      text: textValue,
      createdAt: serverTimestamp()
    });
    closeModal("commentModal");
    state.comments.delete(proposalId);
    const current = state.stats.get(proposalId) || {likes:0,liked:false,comments:0};
    state.stats.set(proposalId, {...current, comments:current.comments+1});
    renderProposals();
    toast("Tu aporte fue publicado.", "success");
  } catch (err) {
    console.error(err);
    toast("No se pudo publicar el aporte. Revisá las reglas de Firestore.", "error");
  }
}

async function deleteComment(proposalId, commentId){
  if (!state.user) return;
  if (!confirm("¿Eliminar este comentario?")) return;
  try {
    await deleteDoc(doc(db, "propuestas", proposalId, "comentarios", commentId));
    state.comments.delete(proposalId);
    const current = state.stats.get(proposalId) || {likes:0,liked:false,comments:0};
    state.stats.set(proposalId, {...current, comments:Math.max(0,current.comments-1)});
    renderProposals();
    toast("Comentario eliminado.");
  } catch (err) { console.error(err); toast("No se pudo eliminar el comentario.", "error"); }
}

async function submitNewProposal(event){
  event.preventDefault();
  if (!loginRequired("presentar una propuesta")) return;
  const title = $("#newProposalTitleInput").value.trim();
  const category = $("#newProposalCategory").value;
  const textValue = $("#newProposalText").value.trim();
  if (title.length < 4 || textValue.length < 15) { toast("Completá un título y una descripción con más detalle.", "error"); return; }
  if (title.length > 90 || textValue.length > 1500) { toast("La propuesta excede el límite de caracteres.", "error"); return; }
  try {
    await addDoc(collection(db, "nuevasPropuestas"), {
      authorUid:state.user.uid,
      authorName:state.user.displayName || "Estudiante",
      photoURL:state.user.photoURL || "",
      title, category, text:textValue,
      status:"pendiente",
      createdAt:serverTimestamp()
    });
    closeModal("newProposalModal");
    $("#newProposalForm").reset();
    toast("Propuesta recibida. Queda registrada para revisión.", "success");
  } catch(err){ console.error(err); toast("No se pudo enviar la propuesta. Revisá las reglas de Firestore.", "error"); }
}

async function loadTransparency(){
  if (!state.configured) {
    $("#incomeTotal").textContent = "—";
    $("#expenseTotal").textContent = "—";
    $("#balanceTotal").textContent = "—";
    $("#transparencyList").innerHTML = `<div class="empty-comments">Firebase no está configurado todavía. Cuando se conecte, acá aparecerán los registros publicados por el Centro.</div>`;
    return;
  }
  try {
    const q = query(collection(db, "transparencia"), orderBy("date", "desc"), limit(100));
    const snap = await getDocs(q);
    let income=0, expense=0;
    const rows=[];
    snap.docs.forEach(s=>{
      const d=s.data(); const amount=Number(d.amount)||0;
      if(d.type==="ingreso") income += amount; else if(d.type==="gasto") expense += amount;
      rows.push({id:s.id,...d});
    });
    $("#incomeTotal").textContent = formatARS(income);
    $("#expenseTotal").textContent = formatARS(expense);
    $("#balanceTotal").textContent = formatARS(income-expense);
    if(!rows.length){
      $("#transparencyList").innerHTML = `<div class="empty-comments">Todavía no hay movimientos publicados.</div>`;
      return;
    }
    $("#transparencyList").innerHTML = rows.map(d => `<div class="transparency-row"><div class="entry-date">${escapeHtml(formatDate(d.date))}</div><div class="entry-main"><b>${escapeHtml(d.concept || "Movimiento")}</b><small>${escapeHtml(d.note || "")}</small></div><div class="entry-amount ${d.type === "ingreso" ? "income" : "expense"}">${d.type === "ingreso" ? "+" : "−"}${escapeHtml(formatARS(Number(d.amount)||0))}</div><div class="entry-tag">${d.type === "ingreso" ? "INGRESO" : "GASTO"}</div></div>`).join("");
  } catch(err){
    console.error(err);
    $("#transparencyList").innerHTML = `<div class="empty-comments">No se pudieron cargar los registros todavía.</div>`;
  }
}

function openProfile(){
  if(!state.user) return;
  $("#profileContent").innerHTML = `<div class="modal-kicker">MI CUENTA</div><h2 id="profileTitle">Sesión activa.</h2><div class="profile-head">${avatarMarkup(state.user, "profile-photo")}<div><small>Cuenta de Google</small><strong>${escapeHtml(state.user.displayName || "Estudiante")}</strong></div></div><div class="profile-actions"><span class="profile-status">Tu correo no se muestra públicamente en los aportes.</span><button class="danger-button" id="signOutModalButton" type="button">Cerrar sesión</button></div>`;
  showModal("profileModal");
}

function configureContactLinks(){
  // Completá estos valores cuando tengan los canales oficiales.
  const links = { instagram:"", email:"", web:"" };
  $$(".contact-placeholder").forEach(a => {
    const value = links[a.dataset.config];
    if(value){ a.href=value; a.target="_blank"; a.rel="noopener noreferrer"; }
    else { a.href="#participa"; a.addEventListener("click", e => { e.preventDefault(); toast("Este canal todavía no fue configurado."); }); }
  });
}

function initNavigation(){
  $("#menuToggle").addEventListener("click", ()=>{
    const menu=$("#mobileMenu"); const open=menu.hidden; menu.hidden=!open; $("#menuToggle").setAttribute("aria-expanded",String(open));
  });
  $$("#mobileMenu a").forEach(a => a.addEventListener("click",()=>{ $("#mobileMenu").hidden=true; $("#menuToggle").setAttribute("aria-expanded","false"); }));
  $("#backToTop").addEventListener("click",()=>window.scrollTo({top:0,behavior:"smooth"}));
  window.addEventListener("scroll",()=>$("#backToTop").classList.toggle("visible",window.scrollY>650),{passive:true});
}

function initTheme(){
  const stored=localStorage.getItem("ajtt-theme");
  if(stored) document.documentElement.dataset.theme=stored;
  $("#themeToggle").addEventListener("click",()=>{
    const next=document.documentElement.dataset.theme==="dark"?"light":"dark";
    document.documentElement.dataset.theme=next; localStorage.setItem("ajtt-theme",next);
    $("#themeToggle").innerHTML=next==="dark"?"☀":"☼";
  });
}

function initFilters(){
  $$(".filter-button").forEach(btn=>btn.addEventListener("click",()=>{
    $$(".filter-button").forEach(x=>x.classList.remove("active")); btn.classList.add("active"); state.activeFilter=btn.dataset.filter; renderProposals();
  }));
  $("#proposalSearch").addEventListener("input",e=>{state.search=e.target.value;renderProposals();});
  $("#proposalSort").addEventListener("change",e=>{state.sort=e.target.value;renderProposals();});
}

function initEvents(){
  $("#signInButton").addEventListener("click",login);
  $("#modalGoogleButton").addEventListener("click",login);
  $("#participateButton").addEventListener("click",()=> state.user ? $("#newProposalButton").scrollIntoView({behavior:"smooth",block:"center"}) : showModal("authModal"));
  $("#heroParticipate").addEventListener("click",()=> state.user ? document.getElementById("participa").scrollIntoView({behavior:"smooth"}) : showModal("authModal"));
  $("#newProposalButton").addEventListener("click",()=>{ if(loginRequired("presentar una propuesta")) showModal("newProposalModal"); });
  $("#commentForm").addEventListener("submit",submitComment);
  $("#newProposalForm").addEventListener("submit",submitNewProposal);
  $("#commentText").addEventListener("input",e=>$("#commentCounter").textContent=`${e.target.value.length} / 1000`);
  $("#newProposalText").addEventListener("input",e=>$("#proposalCounter").textContent=`${e.target.value.length} / 1500`);
  $("#footerAccountButton").addEventListener("click",login);
  $("#footerSignOutButton").addEventListener("click",logout);
  $("#userMenuButton").addEventListener("click",openProfile);
  document.addEventListener("click",e=>{
    const close=e.target.closest("[data-close]"); if(close) closeModal(close.dataset.close);
    const card=e.target.closest(".proposal-card"); const action=e.target.closest("[data-action]");
    if(card && action){ const pid=card.dataset.proposalId; const a=action.dataset.action; if(a==="like") handleLike(pid); if(a==="toggle-comments") openComments(pid); if(a==="apport") openCommentModal(pid); if(a==="delete-comment") deleteComment(action.dataset.proposalId,action.dataset.commentId); }
    if(e.target.classList.contains("modal-backdrop")) closeModal(e.target.id);
  });
  document.addEventListener("keydown",e=>{ if(e.key==="Escape"){ closeAllModals(); $("#mobileMenu").hidden=true; }});
  document.addEventListener("click",e=>{ if(e.target.id==="signOutModalButton") logout(); });
}

async function logout(){
  if(!auth) return;
  try{ await signOut(auth); closeAllModals(); toast("Sesión cerrada."); } catch(err){ console.error(err); toast("No se pudo cerrar la sesión.","error"); }
}

function initReveals(){
  const els=$$(".reveal");
  if(!("IntersectionObserver" in window)){ els.forEach(e=>e.classList.add("is-visible")); return; }
  const io=new IntersectionObserver(entries=>entries.forEach(en=>{if(en.isIntersecting){en.target.classList.add("is-visible");io.unobserve(en.target);}}),{threshold:.08});
  els.forEach(e=>io.observe(e));
}

async function boot(){
  configureContactLinks(); initNavigation(); initTheme(); initFilters(); initEvents(); initReveals(); updateAuthUI(); renderProposals(); loadTransparency();
  if(!state.configured) toast("Sitio en modo presentación: conectá Firebase para activar Google, likes y comentarios.");
  if(auth){
    try { await getRedirectResult(auth); } catch(err){ if(err?.code !== "auth/no-auth-event") toast(authErrorMessage(err),"error"); }
    onAuthStateChanged(auth, async user=>{
      state.user=user;
      updateAuthUI();
      await fetchProposalStats();
    });
  } else {
    await fetchProposalStats();
  }
}

boot();
