// Pegá acá el objeto de configuración que te entrega Firebase Console.
// No hace falta ocultar esta configuración: para Firebase Web la config es pública.
// La seguridad real está en Authentication + Firestore Security Rules.

export const firebaseConfig = {
  apiKey: "REEMPLAZAR",
  authDomain: "REEMPLAZAR.firebaseapp.com",
  projectId: "REEMPLAZAR",
  storageBucket: "REEMPLAZAR.firebasestorage.app",
  messagingSenderId: "REEMPLAZAR",
  appId: "REEMPLAZAR"
};
